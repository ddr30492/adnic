$(document).ready(function() {

    //responsive menu
    $('.hamburger-menu').unbind('click').bind('click', function() {
        $(this).toggleClass('active');
        $(this).parent().find('.header-navigation-part').toggleClass('active');
    });

    if ($(window).width() < 1023) {
        $('#navigation > ul > li > a').unbind('click').bind('click', function() {
            $(this).parent().siblings().removeClass('active');
            $(this).parent().toggleClass('active');
            $(this).parent().siblings().find('.child-menu').removeClass('opened');
            $(this).next().toggleClass('opened');
        });
    }
    var menu = ['Motor', 'Medical', 'Home', 'Travel']

    var heroslider = new Swiper('.hero-slider', {
        effect: "fade",
        speed: 1000,
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.hero-pagination,.hero-dropdown',
            clickable: true,
            renderBullet: function(index, className) {
                return '<span class="' + className + '">' + (menu[index]) + '</span>';
            },
        }
    });

    heroslider.on('slideChange', function() {
        var gethtml = $(".hero-pagination").html();
    });

    $('.hero-pagination').popover({
            html: true
        })
        //for bootstrap carousel slider default value on load
    var firstLoadText = $(document).find('.carousel-indicators li:first-child').text();
    $('.dropdown-toggle #selected').text(firstLoadText);

    //drop-down select value on 
    $('#myCarousel').bind('slide.bs.carousel', function(e) {
        var loadText = $(document).find('.carousel-indicators li.active');
        var curTxt = loadText.next('li').text();
        if (curTxt == '') {
            var firstEleText = $(document).find('.carousel-indicators li:first-child').text();
            $('.dropdown-toggle #selected').addClass('selected');
            $('.dropdown-toggle #selected').text(firstEleText);
        } else {
            $('.dropdown-toggle #selected').text(curTxt);
            //$('.dropdown-toggle #selected').addClass('hi');
        }

    });

    //onselect value
    $('.carousel-indicators li').on('click', function() {
        var selectedText = $(this).text();
        $(this).parent().parent().find('.dropdown-toggle #selected').text(selectedText);
    });



    function secondsTimeSpanToHMS(s) {
        var h = Math.floor(s / 3600); //Get whole hours
        s -= h * 3600;
        var m = Math.floor(s / 60); //Get remaining minutes
        s -= m * 60;

        var hours = (h < 10 ? '0' + h : h);
        var minutes = (m < 10 ? '0' + m : m);
        var seconds = (s < 10 ? '0' + s : s);

        if (hours != "00") {
            return (hours + ":" + minutes + ":" + seconds + " hrs");
        } else if (minutes != "00") {
            return (minutes + ":" + seconds + " mins");
        } else {
            return (minutes + ":" + seconds + " secs");
        }
    }


    $(".carousel-indicators").niceScroll(); // First scrollable DIV

    //--- initial state of elements
    $('.accordian-content').hide()
        //----- click function
    $('.accordian .accordian-title').unbind('click').bind('click', function() {
        $(this).parent().siblings().find('.accordian-title').removeClass('active');
        $(this).parent().siblings().find('.accordian-content').slideUp();
        $(this).removeClass('active');
        $(this).next('.accordian-content').slideUp();

        var selected = $(this).next('.accordian-content');
        if (selected.is(":hidden")) {
            $(this).next('.accordian-content').slideDown();
            $(this).toggleClass('active');
        }
    });
    //testimonial js
    var testimonial = new Swiper('#testimonial-slider', {
        autoHeight: true,
        pagination: {
            el: '#testimonial-slider .swiper-pagination',
        },
        navigation: {
            nextEl: '#testimonialnav .slide-next',
            prevEl: '#testimonialnav .slide-prev',
        },
    });

    //videoslider js
    var videoSliders = new Swiper('#video-slider', {
        slidesPerView: 2.5,
        spaceBetween: 15,
        navigation: {
            nextEl: '#video-slider-nav .slide-next',
            prevEl: '#video-slider-nav .slide-prev',
        },
        breakpoints: {
            1024: {
                slidesPerView: 1.3,
                spaceBetween: 10,
            },
            640: {
                slidesPerView: 2.1,
                spaceBetween: 10,
            },
            480: {
                slidesPerView: 1.1,
                spaceBetween: 10,
            }
        }
    });

    //on scroll toggle class on header
    $(window).scroll(function() {
        if ($(window).scrollTop() >= 50) {
            $('.main-top-header').addClass('fixed-header');
        } else {
            $('.main-top-header').removeClass('fixed-header');
        }
    });


    $('.popup-video').magnificPopup({
        type: 'inline',
        fixedContentPos: true,
        showCloseBtn: true,
        callbacks: {
            open: function() {
                $('html').css('margin-right', 0);
                var gv = $(this.content).find('video')[0];
                var gd = gv.duration();

                $(this.content).find('.time').text(gd + "min");
            },
            close: function() {
                //$(this.content).find('video')[0].pause();
            }
        }
    });

    //for slider dropdown
    $('#thumbs .thumb').unbind('click').bind('click', function() {
        var currText = $(this).text();
        $(this).parent().parent().toggleClass('active');
        $(this).parent().parent().find('.dropdown-selcted-value').text(currText);
    });

    //for tooltip click event
    $('.tooltip-icon').on('click', function() {
        $(this).toggleClass('active').next().slideToggle();
    });

    //for searhbar toggle
    $('.custom-search-bar > .icon-search').on('click', function() {
        $(this).toggleClass('active');
        $(this).next().toggleClass('active');
    });

    //for inner page navigation
    $('.nav-link').on('click', function(evt) {
        window.history.pushState("data", "Title", evt.target.href);
    });

    //for compare clan plus sign
    $('.compare-wrapper .add-icon').on('click', function() {
        $(this).toggleClass('active');
        $('.compare-wrapper .custom-table').slideToggle();
    });

});