$(window).on("load",function() {
  //--- initial state of elements
  $('.accordian-content').hide()
    //----- click function
  $(".accordian-list").find(".accordian-title").click(function() { //---- tabs or buttons
    //---- active class
    $(".accordian-list").find(".accordian-title").removeClass('active');
    $('.accordian-content').slideUp('fast');
    var selected = $(this).next('.accordian-content');
    if (selected.is(":hidden")) {
      $(this).next('.accordian-content').slideDown('fast');
      $(this).toggleClass('active');
    }
  });
});


var testimonial = new Swiper('#testimonial-slider', {
      pagination: {
        el: '#testimonial-slider .swiper-pagination',
      },
      navigation: {
        nextEl: '#testimonialnav .slide-next',
        prevEl: '#testimonialnav .slide-prev',
      },
      autoHeight:true
    });

var menu = ['Motor', 'Medical', 'Home', 'Travel']

var heroslider = new Swiper('.hero-slider', {
      effect:"fade",
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.hero-pagination,.hero-dropdown',
        clickable: true,
        renderBullet: function (index, className) {
          return '<span class="' + className + '">' + (menu[index]) + '</span>';          
        },
      }
    });

heroslider.on('slideChange', function () {
  var gethtml = $(".hero-pagination").html();
});

$('.hero-pagination').popover({
  html:true
})


var videoslider = new Swiper('#video-slider', {
      slidesPerView: 2.5,
      spaceBetween: 15,
      navigation: {
        nextEl: '#video-slider-nav .slide-next',
        prevEl: '#video-slider-nav .slide-prev',
      },
      breakpoints: {

        640: {
          slidesPerView: 1.15,
          spaceBetween: 0,
        }
      }
    });

/*heroslider.on('slideChange', function (index) {
  console.log(heroslider.slides);
});*/


$(window).scroll(function(){

    if ($(window).scrollTop() >= 200) {
          $('header').addClass('up-header');
      }
    else {
        
       // $('header').removeClass('fixed-header');
       $('header').removeClass('up-header');
    }
      

    if ($(window).scrollTop() >= 600) {
        $('header').addClass('fixed-header');
        $('header').removeClass('up-header');
    }
    else {
        
        $('header').removeClass('fixed-header');
       // $('header').removeClass('up-header');
    }
});




/*$('.popup-video').magnificPopup({
  disableOn: 700,
  type: 'iframe',
  mainClass: 'mfp-fade',
  removalDelay: 160,
  preloader: false,
  fixedContentPos: false
});*/

$('.popup-video').magnificPopup({
    //delegate: 'a',
    type: 'inline',
    fixedContentPos: true,
    showCloseBtn: true,
    callbacks: {
        open: function() {
            // https://github.com/dimsemenov/Magnific-Popup/issues/125
            $('html').css('margin-right', 0);
            // Play video on open:
            $(this.content).find('video')[0].play();
        },
        close: function() {
            // Reset video on close:
            $(this.content).find('video')[0].load();
        }
    }
});


/*$("header a").on("click", function(e) {
    $("header").addClass("is-open");
    //e.stopPropagation()
  });
$(document).on("click", function(e) {
    if ($(e.target).is("header") === false) {
      $("header").removeClass("is-open");
    }
 });*/


/*$("header .dropdown").hover(function(e) {
    
    $(this).find(".dropdown-menu").stop(true, true).slideDown();
  });
$(document).hover(function(e) {
  $('header .dropdown-menu').stop(true, true).slideUp();
    if ($(e.target).is("header") === false) {
      $('header .dropdown-menu').stop(true, true).slideUp();
    }
 });*/

    $(function(){
    $("header .dropdown").hover(            
            function() {
                $('header .dropdown-menu', this).stop( true, true ).slideDown(1000);
                $(this).toggleClass('open');
                $("header").addClass("is-open");
            },
            function() {
                $('header .dropdown-menu', this).stop( true, true ).slideUp(1000);
                $(this).toggleClass('open');
                $("header").removeClass("is-open");
            });
    });